package Pack;

import java.util.ArrayList;
import java.util.Scanner;

public class classePrincipal{
	public static void main(String[]args)
	{
		Scanner scanner = new Scanner(System.in);
		System.out.print("Insira aqui quantas pessoas farão parte do cálculo:");
		int quantidade = scanner.nextInt();
		IMCpessoasregistradas[] registradas = new IMCpessoasregistradas[quantidade];
		
		for(int i = 0; i < quantidade; i++)
		{
			System.out.println("Insira as informações sobre a " + (i + 1) + "° pessoa");

            System.out.print("Nome: ");
            String nome = scanner.next();

            System.out.print("Data de Nascimento: ");
            String Data = scanner.next();

            System.out.print("Peso: ");
            double peso = scanner.nextDouble();

            System.out.print("Altura: ");
            double altura = scanner.nextDouble();

            System.out.print("Insira M para Masculino e F para Feminino ");
            String Sexo = scanner.next();

            if (Sexo.equalsIgnoreCase("M"))
            {
                registradas[i] = new Masculino(nome, Data, peso, altura);
            }
            else if (Sexo.equalsIgnoreCase("F"))
            {
                registradas[i] = new Feminino(nome, Data, peso, altura);
            }
		}
	}
}