package Pack;

public abstract class IMCpessoasregistradas extends pessoasRegistradas{
	double peso;
	double altura;
	
	public IMCpessoasregistradas(String nome, String data, double peso, double altura)
	{
		super(nome,data);
		this.peso = peso;
		this.altura = altura;
	}
	
	public double getPeso()
	{
		return peso;
	}
	
	public double getAltura()
	{
		return altura;
	}
	
	public double IMC(double peso, double altura)
	{
		double calculo = peso/(altura*altura);
		return calculo;
	}
	
	abstract public String IMCresultado();
	
	@Override
	public String toString()
	{
		return super.toString() + "Peso: " + peso + "Altura: " + altura;
	}
}
