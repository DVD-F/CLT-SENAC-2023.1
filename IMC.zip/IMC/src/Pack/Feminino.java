package Pack;

public class Feminino extends IMCpessoasregistradas {
public Feminino (String nome, String Data, double peso, double altura)
{
	super(nome, Data, peso, altura);
}

public String IMCresultado()
{
	double calculo = IMC(altura,peso);
	if(calculo < 19)
	{
		return "Você está abaixo do peso";
	}
	
	else if(calculo > 25.8)
	{
		return "Você está acima do peso";
	}
	
	else
	{
		return "Você está num peso condizente com o padrão do IMC";
	}
}
}
