package Pack;

public class pessoasRegistradas {
	public String nome;
	public String Data;
	public pessoasRegistradas(String nome, String Data){
		this.nome = nome;
		this.Data = Data;
	}
	
	
	@Override
	public String toString()
	{
		return "Nome: " + nome + "Data de Nascimento: " + Data;
	}
}
