package Pack;

public class Masculino extends IMCpessoasregistradas {
public Masculino(String nome, String Data, double peso, double altura)
{
	super(nome,Data,peso,altura);
}

public String IMCresultado()
{
	double calculo = IMC(altura,peso);
	
	if (calculo < 20.7)
	{
		return "Você está abaixo do peso";
	}
	
	else if (calculo > 26.4)
	{
		return "Você está acima do peso";
	}
	
	else
	{
		return "Seu peso está nos conformes";
	}
}
}
